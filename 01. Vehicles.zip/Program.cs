﻿using System;

namespace Vehicles
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();
            Car car = new Car(double.Parse(input[1]), double.Parse(input[2]));
            input = Console.ReadLine().Split();
            Truck truck = new Truck(double.Parse(input[1]), double.Parse(input[2]));

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                input = Console.ReadLine().Split();

                string type = input[1];
                string command = input[0];
                double value = double.Parse(input[2]);

                switch (type)
                {
                    case nameof(Car):
                        ExecuteCommand1(car, command, value);
                        break;
                    case nameof(Truck):
                        ExecuteCommand2(truck, command, value);
                        break;
                }

            }

            Console.WriteLine(car);
            Console.WriteLine(truck);
        }

        private static void ExecuteCommand2(Truck truck, string command, double value)
        {
            switch (command)
            {
                case "Drive":
                    Console.WriteLine(truck.Drive(value));
                    break;
                case "Refuel":
                    truck.Refuel(value);
                    break;
                default:
                    break;
            }
        }

        private static void ExecuteCommand1(Car car, string command, double value)
        {
            switch (command)
            {
                case "Drive":
                    Console.WriteLine(car.Drive(value));
                    break;
                case "Refuel":
                    car.Refuel(value);
                    break;
                default:
                    break;
            }
        }
    }
}
